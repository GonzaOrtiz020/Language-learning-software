package baseDeDatos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class RegistrarFrase {

    private Conexion con = new Conexion();
    private Connection conexion;

    public RegistrarFrase() {
        this.con.crearConexion();
        this.conexion = con.getConexion();
    }
    private String insertSQL = "insert into frase(descripcion)" + " values(?)";

    public boolean insert(String descripcion) {
        try {

            PreparedStatement sentencia_preparada = null;
            sentencia_preparada = this.conexion.prepareStatement(this.insertSQL);

            sentencia_preparada.setString(1, descripcion);
       
            // se ejecuta la sentencia
            sentencia_preparada.executeUpdate();
            // se cierra sentencia_preparada
            sentencia_preparada.close();

            JOptionPane.showMessageDialog(null, "La frase fue cargada con éxito");

            return true;

        } catch (Exception e) {
            e.printStackTrace();
            // se notifica que no puedo crearse el usuario
            JOptionPane.showMessageDialog(null,
                    "Ha ocurrido un error y no se pudo" + " añadir la palabra. Error: " + e.getStackTrace() + "", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }

        return false;
    }
}
