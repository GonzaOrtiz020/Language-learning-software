
package baseDeDatos;
public class ConexionTest {
    public static void main(String[] args) {
        Conexion conexion = new Conexion();
        conexion.crearConexion();

        // Prueba de conexión exitosa
        if (conexion.getConexion() != null) {
            System.out.println("Conexión exitosa a la base de datos.");

            // Prueba de consulta
            String consultaSql = "SELECT * FROM usuario";
            boolean existeRegistro = conexion.existeAlgunRegistro(consultaSql);
            if (existeRegistro) {
                System.out.println("La consulta devolvió al menos un registro.");
            } else {
                System.out.println("La consulta no devolvió ningún registro.");
            }
        } else {
            System.out.println("No se pudo establecer la conexión a la base de datos.");
        }
    }
}