package baseDeDatos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class RegistrarPalabra {

    private Conexion con = new Conexion();
    private Connection conexion;

    public RegistrarPalabra() {
        this.con.crearConexion();
        this.conexion = con.getConexion();
    }
    private String insertSQL = "insert into palabra(palabra, id_nivel_idioma, id_etiqueta, id_palabra_categoria, traduccion)" + " values(?,?,?,?,?)";

    public boolean insert(String palabra, int id_nivel_idioma, int id_etiqueta, int id_palabra_categoria, String traduccion) {
        try {

            PreparedStatement sentencia_preparada = null;
            sentencia_preparada = this.conexion.prepareStatement(this.insertSQL);

            
            System.out.println("Palabra cargada: "+palabra);
            sentencia_preparada.setString(1, palabra);
            sentencia_preparada.setInt(2, id_nivel_idioma);
            sentencia_preparada.setInt(3, id_etiqueta);
            sentencia_preparada.setInt(4, id_palabra_categoria);
            sentencia_preparada.setString(5, traduccion);

            // se ejecuta la sentencia
            sentencia_preparada.executeUpdate();
            // se cierra sentencia_preparada
            sentencia_preparada.close();

            JOptionPane.showMessageDialog(null, "La palabra fue cargada con éxito");

            return true;

        } catch (Exception e) {
            e.printStackTrace();
            // se notifica que no puedo crearse el usuario
            JOptionPane.showMessageDialog(null,
                    "Ha ocurrido un error y no se pudo" + " añadir la palabra. Error: " + e.getStackTrace() + "", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }

        return false;
    }

    public int getIdNivel(String nivel) {
        String consultaSQL = "select id_nivel_idioma from nivel_idioma where nivel = '"
                + nivel + "' ";
        int id_nivel_idioma = 0;
        try {
            Statement statement = null;
            statement = this.conexion.createStatement();
            // se ejecuta la consulta y se guarda el resultado en un ResultSet
            ResultSet resultSet = statement.executeQuery(consultaSQL);

            // se guarda la informacion de la cuenta en el vector
            if (resultSet.next()) {
                id_nivel_idioma = resultSet.getInt(1);

            }
            System.out.println("id_nivel_idioma = " + id_nivel_idioma);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return id_nivel_idioma;
    }

    public int getIdEtiqueta(String descripcion) {
        String consultaSQL = "select id_etiqueta from palabra_etiqueta where descripcion = '"
                + descripcion + "' ";
        int idEtiqueta = 0;
        try {
            Statement statement = null;
            statement = this.conexion.createStatement();
            // se ejecuta la consulta y se guarda el resultado en un ResultSet
            ResultSet resultSet = statement.executeQuery(consultaSQL);

            // se guarda la informacion de la cuenta en el vector
            if (resultSet.next()) {
                idEtiqueta = resultSet.getInt(1);
            }
            System.out.println("idEtiqueta = " + idEtiqueta);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return idEtiqueta;
    }

    public int getIdCategoria(String categoria) {
        String consultaSQL = "select id_palabra_categoria from palabra_categoria where categoria= '"
                + categoria + "' ";
        int idCategoria = 0;
        try {
            Statement statement = null;
            statement = this.conexion.createStatement();
            // se ejecuta la consulta y se guarda el resultado en un ResultSet
            ResultSet resultSet = statement.executeQuery(consultaSQL);

            // se guarda la informacion de la cuenta en el vector
            if (resultSet.next()) {
                idCategoria = resultSet.getInt(1);

            }
            System.out.println("idCategoria= " + idCategoria);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return idCategoria;
    }

}
