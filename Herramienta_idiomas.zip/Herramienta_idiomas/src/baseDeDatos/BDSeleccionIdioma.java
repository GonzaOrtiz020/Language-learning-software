package basededatos;

import baseDeDatos.Conexion;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import pantallas.IniciarSesion;
public class BDSeleccionIdioma {
    private Conexion con = new Conexion();
    private Connection conexion;

    private String insertSQL = "insert into usuario_idioma( id_usuario ,id_dioma, id_nivel_idioma)" + " values(?,?,?)"; // usuario
    
   
    
    
    
    
        //select texto_clasificacion_id  from texto_clasificacion tc where descripcion = 'adjetivo'
    
    public boolean insert( int id_idioma,  int id_nivel_idioma) {
		try {
                                                   

			PreparedStatement sentencia_preparada = null;
			sentencia_preparada = this.conexion.prepareStatement(this.insertSQL);
                                                     sentencia_preparada.setInt(1, IniciarSesion.idUsuario);
			sentencia_preparada.setInt(2, id_idioma);
			sentencia_preparada.setInt(3, id_nivel_idioma);
			
			// se ejecuta la sentencia
			sentencia_preparada.executeUpdate();
			// se cierra sentencia_preparada
			sentencia_preparada.close();
			// si el try no tomo una excepcion hasta aqui, se avisa que se creo el usuario
			JOptionPane.showMessageDialog(null, "Se ha seleccionado con exito");

			return true;
			
		} catch (Exception e) {
			e.printStackTrace();
			// se notifica que no puedo crearse el usuario
			JOptionPane.showMessageDialog(null,
					"Ha ocurrido un error y no se pudo" + " Registrar: " + e.getStackTrace() + "", "Error",
					JOptionPane.ERROR_MESSAGE);
		}

		return false;
	}
}