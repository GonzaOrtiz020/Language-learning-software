package test;

import pantallas.CrearCuenta;

public class Test_regcuen {

    public static void main(String[] args) {

        //se muestra la pantalla de inicio de sesion
        CrearCuenta menu = new CrearCuenta();
        menu.mostrarPantalla();

}

}