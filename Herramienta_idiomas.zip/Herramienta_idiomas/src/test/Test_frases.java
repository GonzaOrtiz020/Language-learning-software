
package test;


import pantallas.AñadirFrase;


public class Test_frases {

       public static void main(String[] args) {
              AñadirFrase iniciar = new AñadirFrase();
        iniciar.mostrarPantalla();
    }
}
