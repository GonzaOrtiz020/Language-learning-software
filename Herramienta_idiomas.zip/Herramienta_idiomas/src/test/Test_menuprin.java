
package test;

import pantallas.MenuPrincipal;

public class Test_menuprin {
    public static void main(String args[]) {
       MenuPrincipal menu = new MenuPrincipal();
       menu.mostrarPantalla();
    }
}
