
package test;

import pantallas.MenuPrincipal;
import pantallas.MenuPrincipal2;

public class Test_menuprin2 {
     public static void main(String args[]) {
       MenuPrincipal2 menu2 = new MenuPrincipal2();
       menu2.mostrarPantalla();
}
}
