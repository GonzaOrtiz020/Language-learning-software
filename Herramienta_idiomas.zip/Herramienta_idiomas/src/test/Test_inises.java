package test;


import pantallas.Inicio;
import pantallas.IniciarSesion;
public class Test_inises {

    public static void main(String[] args) {

        //se muestra la pantalla de inicio de sesion
        IniciarSesion iniciars = new IniciarSesion();
        iniciars.mostrarPantalla();
    }

}
