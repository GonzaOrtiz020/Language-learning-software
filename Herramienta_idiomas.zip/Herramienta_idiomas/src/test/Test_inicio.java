
package test;

import pantallas.Inicio;

public class Test_inicio {

    public static void main(String args[]) {
        Inicio iniciar = new Inicio();
        iniciar.mostrarPantalla();
    }
}
     