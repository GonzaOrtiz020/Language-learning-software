
package test;

import javax.swing.SwingUtilities;
import pantallas.SeleccionIdioma;


public class Test_selecidio {

    public static void main(String args[]) {
    
        SwingUtilities.invokeLater(() -> {
            SeleccionIdioma seleccionIdioma = new SeleccionIdioma();
            seleccionIdioma.mostrarPantalla();
        });
    }
    }

