package paquetePrincipal;


import pantallas.Inicio;

public class ejecutarSistema {

	public static void main(String[] args) {
		
		//se muestra la pantalla de inicio de sesion
		Inicio inicio = new Inicio();
		inicio.mostrarPantalla();
				
	}

}
