package pantallas;

import java.awt.Color;
import java.awt.Font;
import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import baseDeDatos.RegistrarPalabra;

public class AñadirPalabras3 {

    private JFrame frame;
    private JTextField txtPalabra;
    private JComboBox<String> cbxNivel;
    private JLabel lblEtiqueta;
    private JComboBox<String> cbxEtiqueta;
    private JComboBox<String> cbxCategoria;
    private JButton btnContinuar;
    private JTextField txTraduccion;

    private RegistrarPalabra registrarpalabra = new RegistrarPalabra();

    public void añadirPalabra(String palabra, int id_nivel_idioma, int id_etiqueta, int id_palabra_categoria, String traduccion) {
        boolean registrado = registrarpalabra.insert(palabra, id_nivel_idioma, id_etiqueta, id_palabra_categoria, traduccion);

    }

    public void mostrarPantalla() {
        // Crear el frame y configurar sus propiedades
        frame = new JFrame("Añadir Palabras");
        frame.setSize(1024, 768);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        // Configurar el color de fondo a un color pastel
        Color colorPastel = new Color(209, 235, 247);
        frame.getContentPane().setBackground(colorPastel);

        // Configurar el JLabel "Añadir Palabra"
        JLabel lblAñadirPalabra = new JLabel("Añadir Palabra");
        lblAñadirPalabra.setFont(new Font("Calibri", Font.BOLD, 48));
        lblAñadirPalabra.setBounds(308, 44, 492, 86);
        lblAñadirPalabra.setHorizontalAlignment(SwingConstants.CENTER);
        frame.add(lblAñadirPalabra);

        // Configurar el JLabel "Palabra"
        JLabel lblPalabra = new JLabel("Palabra");
        lblPalabra.setFont(new Font("Calibri", Font.PLAIN, 24));
        lblPalabra.setBounds(308, 163, 150, 50);
        frame.add(lblPalabra);

        // Configurar el JTextField "txtPalabra"
        txtPalabra = new JTextField();
        txtPalabra.setFont(new Font("Calibri", Font.PLAIN, 18));
        txtPalabra.setBounds(468, 163, 337, 50);
        frame.add(txtPalabra);

        // Configurar el JLabel "Nivel"
        JLabel lblNivel = new JLabel("Nivel");
        lblNivel.setFont(new Font("Calibri", Font.PLAIN, 24));
        lblNivel.setBounds(308, 253, 150, 50);
        frame.add(lblNivel);

        // Configurar el JComboBox "cbxNivel"
        String[] niveles = {"A1", "A2", "B1"};
        cbxNivel = new JComboBox<>(niveles);
        cbxNivel.setFont(new Font("Calibri", Font.PLAIN, 18));
        cbxNivel.setBounds(468, 253, 337, 50);
        frame.add(cbxNivel);

        // Configurar el JLabel "Etiqueta"
        JLabel lblEtiqueta = new JLabel("Etiqueta");
        lblEtiqueta.setFont(new Font("Calibri", Font.PLAIN, 24));
        lblEtiqueta.setBounds(308, 343, 150, 50);
        frame.add(lblEtiqueta);

        // Configurar el JComboBox "cbxEtiqueta"
        String[] etiquetas = {"Comida", "Animales", "Vehiculo"};
        cbxEtiqueta = new JComboBox<>(etiquetas);
        cbxEtiqueta.setFont(new Font("Calibri", Font.PLAIN, 18));
        cbxEtiqueta.setBounds(468, 343, 337, 50);
        frame.add(cbxEtiqueta);

        // Configurar el JLabel "Categoría"
        JLabel lblCategoria = new JLabel("Categoría");
        lblCategoria.setFont(new Font("Calibri", Font.PLAIN, 24));
        lblCategoria.setBounds(308, 433, 150, 50);
        frame.add(lblCategoria);

        // Configurar el JComboBox "cbxCategoria"
        String[] categorias = {"Palabra Nueva", "Palabra Aprendida", "Palabra Dificil"};
        cbxCategoria = new JComboBox<>(categorias);
        cbxCategoria.setFont(new Font("Calibri", Font.PLAIN, 18));
        cbxCategoria.setBounds(468, 433, 337, 50);
        frame.add(cbxCategoria);

        //JLAbel traduccion
        // Configurar el JLabel "Categoría"
        JLabel lblTrad = new JLabel("Traducción");
        lblTrad.setFont(new Font("Calibri", Font.PLAIN, 24));
        lblTrad.setBounds(308, 480, 150, 50);
        frame.add(lblTrad);

        txTraduccion = new JTextField();
        txTraduccion.setFont(new Font("Calibri", Font.PLAIN, 18));
        txTraduccion.setBounds(468, 492, 337, 50);
        frame.add(txTraduccion);

        // Configurar el JTextField "txtPalabra"
        txtPalabra = new JTextField();
        txtPalabra.setFont(new Font("Calibri", Font.PLAIN, 18));
        txtPalabra.setBounds(468, 163, 337, 50);
        frame.add(txtPalabra);

        // Configurar el JButton "Continuar"
        btnContinuar = new JButton("Continuar");
        btnContinuar.setFont(new Font("Calibri", Font.PLAIN, 24));
        btnContinuar.setBounds(308, 580, 497, 86);
        btnContinuar.setBackground(new Color(100, 180, 225));
        btnContinuar.setForeground(Color.BLACK); // Texto en color normal
        frame.add(btnContinuar);

        btnContinuar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String nivelSeleccionado = (String) cbxNivel.getSelectedItem();
                int nivelId = registrarpalabra.getIdNivel(nivelSeleccionado);

                String etiquetaSeleccionada = (String) cbxEtiqueta.getSelectedItem();
                int etiquetaId = registrarpalabra.getIdEtiqueta(etiquetaSeleccionada);

                String categoriaSeleccionada = (String) cbxCategoria.getSelectedItem();
                int categoriaId = registrarpalabra.getIdCategoria(categoriaSeleccionada);

                añadirPalabra(txtPalabra.getText(), nivelId, etiquetaId, categoriaId, "1");

            }
        });

        // Mostrar el frame
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AñadirPalabras3 añadirPalabras = new AñadirPalabras3();
            añadirPalabras.mostrarPantalla();
        });
    }
}
