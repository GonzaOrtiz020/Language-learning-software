package pantallas;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import baseDeDatos.RegistrarCuenta;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


public class RecuperarContrasenha {
	JFrame frame = new JFrame("Recuperar contraseña"); // se crea el frame
	JLabel lblImagenSuperior = new JLabel(""); // label para imagen de parte superior
	JLabel lblEmail = new JLabel("Escriba su e-mail y en instantes, recibirá un correo con su contraseña");
	JTextField tfldEmail = new JTextField();
	JButton btnIniciarSesion = new JButton("Confirmar");

	private RegistrarCuenta usuario = new RegistrarCuenta();

	public void sendEmail() {
		Properties propiedad = new Properties();
		propiedad.setProperty("mail.smtp.host", "smtp.gmail.com");
		propiedad.setProperty("mail.smtp.auth", "true");
		propiedad.setProperty("mail.smtp.starttls.enable", "true");
		propiedad.setProperty("mail.smtp.port", "587");
		propiedad.setProperty("mail.smtp.user", "user");

		// propiedad.setProperty(¡);

		Session sesion = Session.getDefaultInstance(propiedad);
		String correoEnvia = "LanguageHub@gmail.com";
		String contrasena = "12345";
		String receptor = "LanguageHub@gmail.com";
		String asunto = "asunto";
		String mensaje = "mensaje";

		MimeMessage mail = new MimeMessage(sesion);
		try {
			mail.setFrom(new InternetAddress(correoEnvia));
			mail.addRecipient(Message.RecipientType.TO, new InternetAddress(receptor));
			mail.setSubject(asunto);
			mail.setText(mensaje);

			Transport transportar = sesion.getTransport("smtp");
			transportar.connect(correoEnvia, contrasena);
			transportar.sendMessage(mail, mail.getRecipients(Message.RecipientType.TO));
			transportar.close();

			JOptionPane.showMessageDialog(null, "Listo, revise su correo");

		} catch (AddressException ex) {
			ex.printStackTrace();
		} catch (MessagingException ex) {
			ex.printStackTrace();
		}

	}

	public void recuperarContrasenha(String correo) {
		// se debe verificar que el email exista en la base de datos
		if (usuario.existeCorreo(correo)== true) {
			
			// se obtiene el id del usuario
			int id_usuario = usuario.getIdUsuarioConCorreo(correo);
			
			// se recupera la contrase�a
			String informacionCuenta[] = usuario.recuperarCuenta(id_usuario);
			
			System.out.println("Usuario: " + informacionCuenta[0] 
					+" - contraseña: " + informacionCuenta[1] );
			
			JOptionPane.showMessageDialog(null, "Se envió la información de su cuenta a su e-mail.", "Información",
					JOptionPane.INFORMATION_MESSAGE);
			
			// se cierra el frame actual
			this.frame.dispose();
			
		} else // si no existe usuario que tenga ese email
		{
			JOptionPane.showMessageDialog(null, "No existe una cuenta con este E-mail. Verifique el dato", "Alerta",
					JOptionPane.WARNING_MESSAGE);
		}
	}

	public void mostrarPantalla() {

		// imagen de la parte superior de la pantalla
//		ImageIcon icono = new javax.swing.ImageIcon(getClass().getResource(""
//		+ "/imagenes/parte superior.png"));
//		Image imagen = icono.getImage();
//		ImageIcon iconoEscalado = new ImageIcon (imagen.getScaledInstance(1024,108,Image.SCALE_SMOOTH));
//		lblImagenSuperior.setIcon(iconoEscalado);
//		lblImagenSuperior.setBounds(-5, -5, 1024, 108);
//		frame.add(lblImagenSuperior);
		
		// pedir e-mail del usuario
		lblEmail.setBounds(250, 350, 700, 30);
		lblEmail.setFont(new Font("Arial", Font.PLAIN, 20));
		frame.add(lblEmail);
		tfldEmail.setBounds(300, 400, 500, 30);
		frame.add(tfldEmail);

		// boton recuperar contrasenia
		btnIniciarSesion.setBounds(450, 450, 180, 40);
		// frame.getContentPane().add(btnIniciarSesion); // Agrega el boton al panel de
		// contenido del marco
		// se agrega funcion para iniciar sesion al hacer click en el boton
		btnIniciarSesion.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				recuperarContrasenha(tfldEmail.getText());
				// iniciarSesion(tfldEmail.getText(), pfContrasenia.getText());
			}
		});

		frame.add(btnIniciarSesion);

		frame.setSize(1024, 768);// asignar tamanio a frame
		frame.setLocationRelativeTo(null); // centra el frame
		frame.setLayout(null);
		frame.setVisible(true);// se muestra el frame

	}

//	public static void main(String args[]) {
//		RecuperarContrasenia rC = new RecuperarContrasenia();
//		rC.mostrarPantalla();
//		//rC.sendEmail();
//	}

}
