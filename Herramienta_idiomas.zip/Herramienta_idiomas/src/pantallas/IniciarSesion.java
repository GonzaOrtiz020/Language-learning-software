package pantallas;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//se importa la libreria swing para crear pantallas
import javax.swing.*;
import java.awt.Color;
import pantallas.MenuPrincipal;
import baseDeDatos.RegistrarCuenta;
import baseDeDatos.Conexion;


public class IniciarSesion {
public static int idUsuario;
    JFrame frame = new JFrame("Iniciar Sesión"); // frame

    JLabel iniciarSesion = new JLabel("Iniciar Sesión"); // frame
    JLabel lblCorreo = new JLabel("Correo"); // jlabel usuario
    JTextField tfldCorreo = new JTextField(); // jtextfield usuario
    JLabel lblContrasenia = new JLabel("Contraseña"); // jlabel contrase�a
    JPasswordField pfContrasenia = new JPasswordField(); // jtextfield contrase�a
    JButton btnIniciarSesion = new JButton("Iniciar sesión"); // jbutton iniciar sesion
    JLabel lblRecuperarContrasenia = new JLabel("¿Te Olvidaste Wacho? Presiona"); // label para imagen de parte superior
    JButton btnRecuperarContrasena = new JButton("Esta"); // jbutton recuperar contrase�a

    private RegistrarCuenta usuarioRC = new RegistrarCuenta();

    public void iniciarSesion(String usuario, String contrasenha) {
        // se verifican los datos de inicio de sesion
        if (usuarioRC.verificarCorreoYContrasenha(usuario, contrasenha)) {
            // se toma el id_usurio del usuario
            int id_usuario = usuarioRC.getIdUsuario(usuario, contrasenha);
            idUsuario= id_usuario;
            // se muestra un mensaje de bienvenida
            JOptionPane.showMessageDialog(null, "Bienvenido/a");
            // se muestra el menu principal
            MenuPrincipal mP = new MenuPrincipal();
            mP.mostrarPantalla();
            // se cierra la pantalla actual
            frame.dispose();
        } else // si no existe ninguna cuenta con estos datos
        {
            JOptionPane.showMessageDialog(null, "Usuario y/o contraseña no válido(s)", "Error",
                    JOptionPane.ERROR_MESSAGE);
            // System.out.println("Usuario y/o contrase�a no v�lido(s)");
        }
    }

    public void mostrarPantalla() {

        //Titulo
        iniciarSesion.setBounds(343, 84, 450, 81);
        iniciarSesion.setFont(new Font("Calibri", Font.PLAIN, 64));

        frame.add(iniciarSesion);

        Color colorPastel = new Color(209, 235, 247);
        frame.getContentPane().setBackground(colorPastel);

        // pedir correo
        lblCorreo.setBounds(385, 245, 81, 30);
        lblCorreo.setFont(new Font("Calibri", Font.PLAIN, 25));
        frame.add(lblCorreo);

        tfldCorreo.setBounds(385, 286, 296, 47);
        frame.add(tfldCorreo);

        // contrasena
        lblContrasenia.setBounds(385, 384, 200, 30);
        lblContrasenia.setFont(new Font("Calibri", Font.PLAIN, 25));
        frame.add(lblContrasenia);
        pfContrasenia.setBounds(385, 449, 290, 40);
        frame.add(pfContrasenia);

        // boton iniciar sesion
        btnIniciarSesion.setBounds(373, 539, 247, 50);
        btnIniciarSesion.setFont(new Font("Calibri", Font.PLAIN, 25));

        // se agrega funcion para iniciar sesi�n al hacer click en el boton
        btnIniciarSesion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // se toma la contrase�a
                String contrasenia = new String(pfContrasenia.getPassword());

                iniciarSesion(tfldCorreo.getText(), contrasenia);
            }
        });
        frame.add(btnIniciarSesion); // se agrega el bot�n

        // recuperar contrase�a
        lblRecuperarContrasenia.setBounds(683, 630, 270, 19);
        lblRecuperarContrasenia.setFont(new Font("Calibri", Font.PLAIN, 16));
        frame.add(lblRecuperarContrasenia);
        btnRecuperarContrasena.setBounds(702, 659, 198, 24);
        btnRecuperarContrasena.setFont(new Font("Calibri", Font.PLAIN, 24));
        // se agrega funcion para mostrar ventana de recuperar contrase�a
        btnRecuperarContrasena.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                	RecuperarContrasenha recuCont = new RecuperarContrasenha();
                	recuCont.mostrarPantalla();
            }
        });
        frame.add(btnRecuperarContrasena); // se agrega el bot�n

        frame.setSize(1024, 768);// asignar tama�o a frame
        frame.setLocationRelativeTo(null); // centra el frame
        frame.setLayout(null);
        frame.setVisible(true);// se muestra el frame

    }

}