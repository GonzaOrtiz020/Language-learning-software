package pantallas;

import java.awt.Color;
import java.awt.Font;
import javax.swing.*;

public class SeleccionIdioma {

    private JFrame frame;
    private JComboBox<String> cbxidiomas;
    private JComboBox<String> cbxnivel;
    private JButton btnContinuar;

    public void mostrarPantalla() {
        // Crear el frame y configurar sus propiedades
        frame = new JFrame("Seleccionar Idioma");
        frame.setSize(1024, 768);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        // Configurar el color de fondo a un color pastel
        Color colorPastel = new Color(209, 235, 247);
        frame.getContentPane().setBackground(colorPastel);

        // Configurar el JLabel "Seleccion Idioma"
        JLabel lblSeleccionIdioma = new JLabel("Seleccion Idioma");
        lblSeleccionIdioma.setFont(new Font("Calibri", Font.BOLD, 48));
        lblSeleccionIdioma.setBounds(308, 44, 492, 86);
        lblSeleccionIdioma.setHorizontalAlignment(SwingConstants.CENTER);
        frame.add(lblSeleccionIdioma);

        // Configurar el JComboBox "cbxidiomas"
        String[] idiomas = {"Español", "Deutsch", "Ingles"};
        cbxidiomas = new JComboBox<>(idiomas);
        cbxidiomas.setFont(new Font("Calibri", Font.PLAIN, 18));
        cbxidiomas.setBounds(313, 163, 492, 50); // Aumentar la altura a 50
        frame.add(cbxidiomas);

        // Configurar el JLabel "Seleccion Nivel"
        JLabel lblSeleccionNivel = new JLabel("Seleccion Nivel");
        lblSeleccionNivel.setFont(new Font("Calibri", Font.BOLD, 48));
        lblSeleccionNivel.setBounds(308, 331, 492, 86);
        lblSeleccionNivel.setHorizontalAlignment(SwingConstants.CENTER);
        frame.add(lblSeleccionNivel);

        // Configurar el JComboBox "cbxnivel"
        String[] niveles = {"A1", "A2", "B1"};
        cbxnivel = new JComboBox<>(niveles);
        cbxnivel.setFont(new Font("Calibri", Font.PLAIN, 18));
        cbxnivel.setBounds(313, 445, 492, 50); // Aumentar la altura a 50
        frame.add(cbxnivel);

        // Configurar el JButton "Continuar"
        btnContinuar = new JButton("Continuar");
        btnContinuar.setFont(new Font("Calibri", Font.PLAIN, 24)); // Utilizar el estilo "Plain"
        btnContinuar.setBounds(313, 561, 492, 86);
        btnContinuar.setBackground(new Color(100, 180, 225));
        btnContinuar.setForeground(Color.BLACK); // Texto en color normal
        frame.add(btnContinuar);

        // Mostrar el frame
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SeleccionIdioma seleccionIdioma = new SeleccionIdioma();
            seleccionIdioma.mostrarPantalla();
        });
    }
}