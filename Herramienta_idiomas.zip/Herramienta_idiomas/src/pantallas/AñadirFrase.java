
package pantallas;

import baseDeDatos.RegistrarFrase;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class AñadirFrase {
      private JFrame frame;
    private JTextField txtPalabra;
    
       private RegistrarFrase registrarfrase = new RegistrarFrase();
       
           public void añadirFrase(String descripcion) {
        boolean registrado = registrarfrase.insert(descripcion);
    }
             public void mostrarPantalla() {
                  frame = new JFrame("Añadir Frase");
        frame.setSize(1024, 768);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        
          Color colorPastel = new Color(209, 235, 247);
        frame.getContentPane().setBackground(colorPastel);
        
             JLabel lblAñadirFrase = new JLabel("Añadir Frase");
         lblAñadirFrase.setFont(new Font("Calibri", Font.BOLD, 48));
         lblAñadirFrase.setBounds(308, 44, 492, 86);
         lblAñadirFrase.setHorizontalAlignment(SwingConstants.CENTER);
        frame.add( lblAñadirFrase);

        // Configurar el JLabel "Frase"
        JLabel lblFrase = new JLabel("Frase");
        lblFrase.setFont(new Font("Calibri", Font.PLAIN, 24));
        lblFrase.setBounds(308, 163, 150, 50);
          frame.add(lblFrase);

        // Configurar el JTextField "txtFrase"
       JTextField txtFrase = new JTextField();
        txtFrase.setFont(new Font("Calibri", Font.PLAIN, 18));
        txtFrase.setBounds(468, 163, 337, 50);
        frame.add(txtFrase);
        
          JButton btnContinuar = new JButton("Continuar");
        btnContinuar.setFont(new Font("Calibri", Font.PLAIN, 24));
        btnContinuar.setBounds(308, 523, 497, 86);
        btnContinuar.setBackground(new Color(100, 180, 225));
        btnContinuar.setForeground(Color.BLACK); // Texto en color normal
        frame.add(btnContinuar);
        
        btnContinuar.addActionListener(new ActionListener) {
                 @Override
                 
                 public void actionPerformed(ActionEvent e) {
                   añadirFrase.get
        }
                 
             }
         frame.setVisible(true);
             } 
}