package pantallas;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.sql.ResultSet;

import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

import javax.swing.JComboBox;
import java.awt.event.ActionListener;

public class MenuPrincipal2 {

    JFrame frame = new JFrame("Menu Principal"); // frame

    private JLabel lblMenuPrincipal = new JLabel("Menu Principal");
    private JButton btnAñadirPalabras = new JButton("Añadir Palabras");


    public void mostrarPantalla() {
        // titulo
        lblMenuPrincipal.setBounds(308, 44, 492, 86);
        lblMenuPrincipal.setFont(new Font("Calibri", Font.PLAIN, 64));
        frame.add(lblMenuPrincipal);
       
        // Boton Practicas
        btnAñadirPalabras.setBounds(313, 157, 450, 86);
        btnAñadirPalabras.setFont(new Font("Calibri", Font.PLAIN, 20));
        btnAñadirPalabras.addActionListener(
                new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        AñadirPalabras3 añadirpalabras = new AñadirPalabras3();
                        añadirpalabras.mostrarPantalla();
                    }
                });
        
        
        frame.add(btnAñadirPalabras);

        frame.setSize(1024, 768);// asignar tamanio a frame
        frame.setLocationRelativeTo(null); //centra el frame
        frame.setLayout(null);
        frame.setVisible(true);// se muestra el frame

//        JOptionPane.showMessageDialog(null, "id_usuario: " + this.id_usuario);
    }

}