package pantallas;

import java.awt.Color;
import java.awt.Font;
import javax.swing.*;

import baseDeDatos.Conexion;
import baseDeDatos.RegistrarCuenta;

public class CrearCuenta {

    JFrame frame = new JFrame("Registrarse"); // frame

    private JLabel lblRegistrarse = new JLabel("Registrarse");
    private JLabel lblCorreo = new JLabel("Correo");
    private JLabel lblNombre = new JLabel("Nombre");
    private JLabel lblApellido = new JLabel("Apellido");
    private JLabel lblContraseña = new JLabel("Contraseña");
    private JLabel lblConfirmar = new JLabel("Confirmar Contraseña");
    private JLabel lblTipo = new JLabel("Tipo de Usuario");

    private JTextField tfCorreo = new JTextField();
    private JTextField tfNombre = new JTextField();
    private JTextField tfApellido = new JTextField();
    private JComboBox<String> cbxTipoUsuario;
    private JButton btnRegistrarse = new JButton("Registrarse");

    private JPasswordField passContraseña = new JPasswordField();
    private JPasswordField passConfirmar = new JPasswordField();

    private RegistrarCuenta usuarioRC = new RegistrarCuenta();

    public void mostrarPantalla() {
        // Configurar el frame y sus propiedades
        frame.setSize(1024, 768);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        // Configurar el color de fondo a un color pastel
        Color colorPastel = new Color(209, 235, 247);
        frame.getContentPane().setBackground(colorPastel);

        // Configurar el JLabel "Registrarse"
        lblRegistrarse.setBounds(311, 33, 500, 81);
        lblRegistrarse.setFont(new Font("Calibri", Font.PLAIN, 64));
        frame.add(lblRegistrarse);

        // Configurar el JLabel "Correo"
        lblCorreo.setBounds(389, 137, 100, 30);
        lblCorreo.setFont(new Font("Calibri", Font.PLAIN, 18));
        frame.add(lblCorreo);

        // Configurar el JTextField "tfCorreo"
        tfCorreo.setBounds(389, 168, 197, 32);
        frame.add(tfCorreo);

        // Configurar el JLabel "Nombre"
        lblNombre.setBounds(389, 220, 100, 30);
        lblNombre.setFont(new Font("Calibri", Font.PLAIN, 18));
        frame.add(lblNombre);

        // Configurar el JTextField "tfNombre"
        tfNombre.setBounds(389, 263, 197, 32);
        frame.add(tfNombre);

        // Configurar el JLabel "Apellido"
        lblApellido.setBounds(389, 318, 100, 30);
        lblApellido.setFont(new Font("Calibri", Font.PLAIN, 18));
        frame.add(lblApellido);

        // Configurar el JTextField "tfApellido"
        tfApellido.setBounds(389, 349, 197, 32);
        frame.add(tfApellido);

        // Configurar el JLabel "Contraseña"
        lblContraseña.setBounds(389, 396, 100, 30);
        lblContraseña.setFont(new Font("Calibri", Font.PLAIN, 18));
        frame.add(lblContraseña);

        // Configurar el JPasswordField "passContraseña"
        passContraseña.setBounds(389, 438, 197, 30);
        frame.add(passContraseña);

        // Configurar el JLabel "Confirmar Contraseña"
        lblConfirmar.setBounds(389, 485, 200, 30);
        lblConfirmar.setFont(new Font("Calibri", Font.PLAIN, 18));
        frame.add(lblConfirmar);

        // Configurar el JPasswordField "passConfirmar"
        passConfirmar.setBounds(389, 530, 197, 30);
        frame.add(passConfirmar);

        // Configurar el JLabel "Tipo de Usuario"
        lblTipo.setBounds(389, 571, 500, 30);
        lblTipo.setFont(new Font("Calibri", Font.PLAIN, 18));
        frame.add(lblTipo);

        // Configurar el JComboBox "cbxTipoUsuario"
        String[] tiposUsuario = {"Administrador", "Alumno"};
        cbxTipoUsuario = new JComboBox<>(tiposUsuario);
        cbxTipoUsuario.setFont(new Font("Calibri", Font.PLAIN, 18));
        cbxTipoUsuario.setBounds(389, 606, 197, 32);
        frame.add(cbxTipoUsuario);

        // Configurar el JButton "Registrarse"
        btnRegistrarse.setBounds(721, 326, 198, 39);
        btnRegistrarse.setFont(new Font("Calibri", Font.PLAIN, 20));
        frame.add(btnRegistrarse);

        // Agregar ActionListener al botón "Registrarse"
        btnRegistrarse.addActionListener(e -> registrarUsuario());

        // Mostrar el frame
        frame.setVisible(true);
    }

    private void registrarUsuario() {
        String correo = tfCorreo.getText();
        String nombre = tfNombre.getText();
        String apellido = tfApellido.getText();
        String contraseña = new String(passContraseña.getPassword());
        String confirmarContraseña = new String(passConfirmar.getPassword());
        int tipoUsuario = cbxTipoUsuario.getSelectedIndex(); // 0: Administrador, 1: Alumno

        if (validarCampos(correo, nombre, apellido, contraseña, confirmarContraseña)) {
            if (!usuarioRC.existeCorreo(correo)) {
                if (!usuarioRC.cuentaYaRegistrada(correo)) {
                    if (contraseña.equals(confirmarContraseña)) {
                        if (usuarioRC.insert(nombre, apellido, correo, contraseña, tipoUsuario)) {
                            JOptionPane.showMessageDialog(frame, "Usuario registrado con éxito");
                            // Lógica adicional después del registro exitoso
                        } else {
                            JOptionPane.showMessageDialog(frame, "No se pudo registrar el usuario", "Error",
                                    JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(frame, "Las contraseñas no coinciden", "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Ya existe una cuenta registrada con ese correo", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(frame, "El correo ingresado ya está registrado", "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Debe completar todos los campos", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean validarCampos(String correo, String nombre, String apellido, String contraseña,
            String confirmarContraseña) {
        return !correo.isEmpty() && !nombre.isEmpty() && !apellido.isEmpty() && !contraseña.isEmpty()
                && !confirmarContraseña.isEmpty();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            CrearCuenta registrarse = new CrearCuenta();
            registrarse.mostrarPantalla();
        });
    }
}