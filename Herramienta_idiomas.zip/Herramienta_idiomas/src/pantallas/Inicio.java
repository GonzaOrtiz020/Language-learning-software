package pantallas;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import baseDeDatos.RegistrarCuenta;
import baseDeDatos.Conexion;
import pantallas.IniciarSesion;
import pantallas.CrearCuenta;

public class Inicio {

    JLabel lblLanguageHub = new JLabel("LanguageHub - Welcome");
    JFrame frame = new JFrame("LanguageHub - Inicio"); // fram
    JButton btnIniciarSesion = new JButton("Iniciar sesión"); // jbutton iniciar sesion
    JButton btnCrearCuenta = new JButton("Registrarse"); // jbutton registrase

    public void mostrarPantalla() {

        // Titulo
        lblLanguageHub.setBounds(300, 150, 500, 72);

        lblLanguageHub.setFont(new Font("Calibri", Font.PLAIN, 38));

        frame.add(lblLanguageHub);

        // boton iniciar sesion
        btnIniciarSesion.setBounds(
                250, 502, 255, 72); // tamanio y ubicacion
        //btnIniciarSesion.setBackground(Color.blue); // color del boton
        btnIniciarSesion.setFont(
                new Font("Calibri", Font.PLAIN, 26));
        // se agrega funcion para iniciar sesion al hacer click en el boton
        btnIniciarSesion.addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e
            ) {
                // se muestra la pantalla para iniciar sesion 
                IniciarSesion iniSes = new IniciarSesion();
                iniSes.mostrarPantalla();

                // se cierra la pantalla actual
                frame.dispose();
            }
        }
        );

        frame.add(btnIniciarSesion); // se agrega el boton

        // boton crear cuenta
        btnCrearCuenta.setBounds(
                550, 502, 255, 72);
        //btnCrearCuenta.setBackground(Color.blue); // color del boton
        btnCrearCuenta.setFont(
                new Font("Calibri", Font.PLAIN, 26));
        // se agrega funcion para mostrar ventana de recuperar contrasenia
        btnCrearCuenta.addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0
            ) {
              CrearCuenta registrarCuen = new CrearCuenta();
               registrarCuen.mostrarPantalla();

                //se cierra la pantalla actual
                frame.dispose();
            }
        }
        );
        frame.add(btnCrearCuenta); // se agrega el boton

        frame.setSize(
                1024, 768);// asignar tamanio a frame
        frame.setLocationRelativeTo(
                null); // centra el frame
        frame.setLayout(
                null);
        frame.setVisible(
                true);// se muestra el frame

    }
}