package pantallas;

import javax.swing.*;
import java.awt.*;

public class Frases {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Frases frases = new Frases();
            frases.mostrarPantallas();
        });
    }

    public void mostrarPantallas() {
        JFrame frame = new JFrame();
        frame.setSize(1024, 768);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(new Color(209, 235, 247)); // Color pastel (RGB 209, 235, 247)
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        panel.setLayout(null);
        panel.setPreferredSize(new Dimension(1024, 768));
        panel.setBackground(new Color(209, 235, 247)); // Color pastel (RGB 209, 235, 247)

        Font calibriFontLarge = new Font("Calibri", Font.PLAIN, 48); // Fuente "Calibri" tamaño 48
        Font calibriFontMedium = new Font("Calibri", Font.PLAIN, 36); // Fuente "Calibri" tamaño 36

        // Título "Frases"
        JLabel titulo = new JLabel("Frases");
        titulo.setFont(calibriFontLarge);
        titulo.setBounds(525, 44, 492, 86);
        panel.add(titulo);

        // Etiquetas en español
        JPanel panelEspañol = new JPanel(new GridLayout(0, 1));
        panelEspañol.setBounds(235, 180, 300, 420);
        panel.add(panelEspañol);

        JLabel frase1 = new JLabel("Hola");
        frase1.setFont(calibriFontMedium);
        frase1.setHorizontalAlignment(SwingConstants.CENTER);
        panelEspañol.add(frase1);

        JLabel frase2 = new JLabel("No");
        frase2.setFont(calibriFontMedium);
        frase2.setHorizontalAlignment(SwingConstants.CENTER);
        panelEspañol.add(frase2);

        JLabel frase3 = new JLabel("Si");
        frase3.setFont(calibriFontMedium);
        frase3.setHorizontalAlignment(SwingConstants.CENTER);
        panelEspañol.add(frase3);

        JLabel frase4 = new JLabel("Chau");
        frase4.setFont(calibriFontMedium);
        frase4.setHorizontalAlignment(SwingConstants.CENTER);
        panelEspañol.add(frase4);

        JLabel frase5 = new JLabel("Me llamo Juan");
        frase5.setFont(calibriFontMedium);
        frase5.setHorizontalAlignment(SwingConstants.CENTER);
        panelEspañol.add(frase5);

        // Etiquetas en inglés
        JPanel panelIngles = new JPanel(new GridLayout(0, 1));
        panelIngles.setBounds(689, 180, 300, 420);
        panel.add(panelIngles);

        JLabel frase6 = new JLabel("Hello");
        frase6.setFont(calibriFontMedium);
        frase6.setHorizontalAlignment(SwingConstants.CENTER);
        panelIngles.add(frase6);

        JLabel frase7 = new JLabel("No");
        frase7.setFont(calibriFontMedium);
        frase7.setHorizontalAlignment(SwingConstants.CENTER);
        panelIngles.add(frase7);

        JLabel frase8 = new JLabel("Yes");
        frase8.setFont(calibriFontMedium);
        frase8.setHorizontalAlignment(SwingConstants.CENTER);
        panelIngles.add(frase8);

        JLabel frase9 = new JLabel("Bye");
        frase9.setFont(calibriFontMedium);
        frase9.setHorizontalAlignment(SwingConstants.CENTER);
        panelIngles.add(frase9);

        JLabel frase10 = new JLabel("My name is Juan");
        frase10.setFont(calibriFontMedium);
        frase10.setHorizontalAlignment(SwingConstants.CENTER);
        panelIngles.add(frase10);

        frame.add(panel);
        frame.pack();
        frame.setVisible(true);
    }
}